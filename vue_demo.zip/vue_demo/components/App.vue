<template>
    <div>
        {{ value }}
    </div>
</template>

<script>
    export default {
        name: "App",
        data () {
            return {
                value: "windows sucks, windows cant watch, windows cant do anything",
            }
        }

    }
</script>

<style scoped>

</style>