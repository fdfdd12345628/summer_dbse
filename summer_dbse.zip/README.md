# summer_dbse
summer project, social network
install requirement.txt by `pip3 install -r requirement.txt`
run demo server by `python3 manage.py runserver`
run server with ssl by `daphne -e ssl:443:privateKey=localhost-key.pem:certKey=localhost.pem facebock.asgi:application`

